# -*- coding: utf-8 -*-
"""
/***************************************************************************
 CanvasDialog
                                 A QGIS plugin
 Canvas
                             -------------------
        begin                : 2018-12-03
        git sha              : $Format:%H$
        copyright            : (C) 2018 by Canvas
        email                : DHK@hermesys.co.kr
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/
"""
import os
import sys
import shutil
import glob
import tempfile

from qgis.core import *
from qgis.gui import *

from PyQt5 import *
from PyQt5.QtGui import *
from PyQt5.QtCore import *
from qgis.core import QgsProject
from PyQt5.QtWidgets import * 
from PyQt5.QtWidgets import QAbstractItemView
from PyQt5.QtCore import pyqtSignal #2026.07.30. 최.
from .Canvas_Tools import RectangleMapTool

from .lib.Util import *
from .lib.File_Class import *
from .Make_PRJ_dialog import *
from xml.etree import ElementTree as ET
from PyQt5.QtCore import QTimer

from PIL import Image, ImageDraw
import requests


FORM_CLASS, _ = uic.loadUiType(os.path.join(os.path.dirname(__file__), 'Canvas_dialog_base.ui'))
class CanvasDialog(QtWidgets.QDialog, FORM_CLASS):

    simulationFinished = pyqtSignal()  #2026.07.30. 최.

    def __init__(self, parent=None, dempath="", projectfile="",
                 Type="", status=None, simulation_started_at=None):
        super(CanvasDialog, self).__init__(parent)
        self.setupUi(self)

        # 이 Canvas 창만의 상태
        self.dem_path = dempath
        self.project_file = projectfile
        self.simulation_type = Type
        self.status = status if status is not None else {"running": False}
        self.simulation_started_at = simulation_started_at

        self.default_qml_file = os.path.join(
            GetScriptDirectory_Path(),
            "QML",
            "QGIS_style_depth_ClearNull_all_blue_red.qml"
        )
        self.dem_qml_file = os.path.join(
            GetScriptDirectory_Path(),
            "QML",
            "QGIS_style_DEM.qml"
        )

        self.slide_flag = False
        self.Dic_Tree_List = {}
        self.Temp_Layer_Name = []
        self.Layer_Name = []

        self.SetIni()

        self.setWindowFlags(
            Qt.Window |
            Qt.WindowTitleHint |
            Qt.CustomizeWindowHint
        )


    def SetIni(self):
        try:
            self.layer = None
            self.base_map = None
            self._out_file_sizes = {}
            css = "QGroupBox{padding-top:15px;margin-top:-15px;}"
            self.groupBox_4.setStyleSheet(css)
            self.groupBox_7.setStyleSheet(css)

            # Canvas 초기화
            self.Clear_Canvas()

            # 지도 도구
            self.btn_Extent.clicked.connect(self.ZoomtoExtent)
            self.btn_Pan.clicked.connect(self.canvas_pan)

            # 폴더·파일 선택
            self.btnSelect_Folder.clicked.connect(
                lambda: self.Select_Folder(self.txtPng_Folder_Path)
            )
            self.btnDial_gif_path.clicked.connect(
                lambda: self.Select_make_path(self.txtGif_Path)
            )
            self.btn_QML_Dialog.clicked.connect(
                lambda: self.Select_QML_path(self.txt_QML_Path)
            )
            self.txtPng_Folder_Path.textChanged.connect(
                self.AddPngsInAfolderToList
            )

            # 아이콘
            icon_dir = os.path.join(GetScriptDirectory_Path(), "icon")

            self.btnUp.setIcon(QIcon(os.path.join(icon_dir, "up.png")))
            self.btnRemove.setIcon(QIcon(os.path.join(icon_dir, "remove.png")))
            self.btnDown.setIcon(QIcon(os.path.join(icon_dir, "down.png")))
            self.btn_slideStop.setIcon(QIcon(os.path.join(icon_dir, "stop.png")))

            # PNG → GIF
            self.btnUp.clicked.connect(self.MoveUpPng)
            self.btnDown.clicked.connect(self.MoveDownPng)
            self.btnRemove.clicked.connect(self.RemovePng)
            self.btn_Convert_gif.clicked.connect(self.make_gif)

            # 결과 레이어 목록
            self.btn_Get_LayerFile.clicked.connect(self.Get_Layer_Files)
            self.btn_del.clicked.connect(self.Select_tree_del)
            self.btn_clearAllFiles.clicked.connect(self.Clear_tree_all)
            self.Layer_List_Tree.itemDoubleClicked.connect(self.itemClicked)
            self.Layer_List_Tree.setSelectionMode(
                QAbstractItemView.ExtendedSelection
            )
            self.Layer_List_Tree.setHeaderHidden(True)
            self.Layer_List_Tree.setColumnWidth(0, 1200)
            self.Layer_List_Tree.setHorizontalScrollBarPolicy(
                Qt.ScrollBarAsNeeded
            )

            # QML
            self.btn_QML_Apply.clicked.connect(self.Apply_QML)

            # 최대값 ASC 생성
            self.btn_maxValuePath.clicked.connect(
                lambda: self.Save_file(self.txt_maxValuePath)
            )
            self.btn_maxValueRun.clicked.connect(self.runMaxValue)
            self.spb_maxValue.setDecimals(5)
            self.spb_maxValue.setMinimum(-99999)
            self.spb_maxValue.setMaximum(99999)

            # PNG 생성
            self.btn_pngPath.clicked.connect(
                lambda: self.Select_Folder(self.txt_pngPath)
            )
            self.btn_convertPng.clicked.connect(self.pngConvertImage)

            # 배경지도
            self.cmb_base_map.clear()
            self.cmb_base_map.addItems([
                " select map ",
                " google map ",
                " DEM "
            ])
            self.cmb_base_map.currentIndexChanged.connect(
                self.baseMap_Changed
            )

            # 슬라이더/재생
            self.slide_count = 0
            self.pause_count = 0
            self.slide_control = False

            self.sld_slideBar.setTickPosition(1)
            self.sld_slideBar.setMaximum(0)
            self.sld_slideBar.valueChanged.connect(self.on_changed_value)

            self.btn_slideStop.clicked.connect(self.slideStopEvent)
            self.btn_slidePause.clicked.connect(self.slidePauseEvent)

            # 이미지 생성 체크 상태
            self.chk_makeImage.stateChanged.connect(self.enableSlide)

            self.btn_pngPath.setEnabled(False)
            self.btn_convertPng.setEnabled(False)
            self.txt_pngPath.setEnabled(False)

            # 실시간 G2D 결과 탐색 타이머
            self.current_timer = QTimer(self)
            self.current_timer.setInterval(500)
            self.current_timer.timeout.connect(self.Out_file_List_Add_tree)

            # 기존 결과 재생 / PNG 연속 생성용 타이머
            self.playback_timer = QTimer(self)
            self.playback_timer.setSingleShot(True)
            self.playback_timer.timeout.connect(self.slideImage)
            self.playback_active = False

            # settings.xml의 QML 경로를 먼저 적용
            self.settingsfile_load_setting()

            # DEM과 연결된 QML이 없으면 생성
            self.Check_DEM_QML()

            # 기존 결과 표시 / 실시간 결과 표시
            if self.simulation_type == "NO":
                self.Set_Tree_Widget()
                self.sld_slideBar.setMaximum(
                    max(0, len(self.Dic_Tree_List) - 1)
                )
            else:
                self.timer_start_end()

            # 초기 배경지도: DEM
            self.cmb_base_map.setCurrentIndex(2)

            # 닫기
            self.btn_Close.clicked.connect(self.Close_Form)

        except Exception as e:
            MsError(e)


    def Close_Form(self):
        if self.is_simulation_running():
            MsError("Please terminate the simulation process first.")
            return

        self.stop_canvas_timers()

        self.Clear_Canvas()
        self.hide()

    def stop_canvas_timers(self):
        if self.current_timer.isActive():
            self.current_timer.stop()

        if self.playback_timer.isActive():
            self.playback_timer.stop()

    def on_changed_value(self, index):
        try:
            if self.Layer_Name and not self.slide_flag:
                select_item = self.Layer_Name[index]
                self.Show_Canvas_Layer(index, select_item)
        except Exception as e:
            MsError(e)


    def settingsfile_load_setting(self):
        xml_path = os.path.join(
            GetScriptDirectory_Path(),
            "Settings",
            "settings.xml"
        )
        xml_parser = ET.XMLParser(encoding="utf-8")
        root = ET.parse(xml_path, parser=xml_parser).getroot()

        for element in root.findall("demqml"):
            path = element.findtext("path")

            if path:
                self.dem_qml_file = path

        for element in root.findall("outqml"):
            path = element.findtext("path")

            if path:
                self.txt_QML_Path.setText(path)
            else:
                self.txt_QML_Path.setText(self.default_qml_file)
 
    #2019-10-16 박: DEM 파일의 QML 서식 파일이 없으면 기본 파일 생성 
    def Check_DEM_QML(self):
        qml_path = os.path.splitext(self.dem_path)[0] + ".qml"

        if not ChFile_Exists(qml_path):
            self.Copy_file(qml_path, "DEM")

    def Apply_QML(self):
        try:
            qml_path = self.txt_QML_Path.text()
            if not ChFile_Exists(qml_path):
                MsError("The path to the QML file you entered is not valid.")
                return

            self.default_qml_file = qml_path
            for path in self.Temp_Layer_Name:
                self.Copy_file(path, "Apply")
            
            # 현재 Canvas에 보이는 결과 레이어에 즉시 스타일 적용
            if self.layer is not None and self.layer.isValid():
                self.layer.loadNamedStyle(qml_path)
                self.layer.triggerRepaint()
                self.Canvas_Main.refresh()

            MsInfo("QML file has been applied.")

        except Exception as e:
            MsError(e)


    def Timer_Stop(self):
        self.current_timer.stop()
        # 타이머 종료시에 QML 파일 생성
        #for c in self.Dic_Tree_List.keys():
        #    self.Copy_file(str(self.Dic_Tree_List[c]),"QML")

    def timer_start_end(self):
        try:
            self.btn_Close.setEnabled(False)
            self.btn_Close.setText(" Running simulation ")
            self.btn_slidePause.setEnabled(False)
            self.btn_slideStop.setEnabled(False)
            self.sld_slideBar.setEnabled(False)
            self.chk_makeImage.setEnabled(False)

            # 이번 시뮬레이션의 실시간 결과 목록을 빈 상태로 시작
            self.Layer_List_Tree.clear()
            self.Dic_Tree_List.clear()
            self.Layer_Name.clear()
            self.Temp_Layer_Name.clear()
            self._out_file_sizes.clear()

            self.sld_slideBar.blockSignals(True)
            self.sld_slideBar.setMaximum(0)
            self.sld_slideBar.setValue(0)
            self.sld_slideBar.blockSignals(False)

            self.slide_count = 0
            self.pause_count = 0

            # 한 번 즉시 탐색:
            # simulation_started_at 이전 OUT 파일은
            # Out_file_List_Add_tree()에서 무시됨
            self.Out_file_List_Add_tree()

            # 이후 새로 생성되는 OUT 파일을 주기적으로 탐색
            self.current_timer.start(500)

        except Exception as e:
            MsError(e)

    def Out_file_List_Add_tree(self):
        try:
            folder_path = GetFileDirectory_Path(self.project_file)
            if not CheckFolder(folder_path):
                return

            is_final_scan = not self.is_simulation_running()
            output_files = sorted(
                glob.glob(os.path.join(folder_path, "*.out")),
                key=os.path.getctime
            )

            last_added_name = None
            for path in output_files:
                name = os.path.splitext(
                    os.path.basename(path)
                )[0].upper()
                
                # 시뮬레이션 시작 이전의 기존 OUT 파일은 무시
                if (self.simulation_started_at is not None and
                        os.path.getmtime(path) < self.simulation_started_at):
                    continue

                # 새 결과 파일명과 같은 QML 생성
                self.Copy_file(path, "QML")

                # 이미 Tree에 있는 결과는 다시 추가하지 않음
                if name in self.Dic_Tree_List:
                    continue
                # G2D가 쓰기 중인 파일은 다음 타이머에서 재시도
                if not self.is_ready_raster(path, final_scan=is_final_scan):
                    continue
                # 새 결과만 Tree / dictionary에 추가
                self.Dic_Tree_List[name] = path
                self.Layer_List_Tree.addTopLevelItem(
                    QTreeWidgetItem([name])
                )
                last_added_name = name

            # Tree 순서, Layer_Name, slider 범위 동기화
            if last_added_name is not None:
                self.sync_result_list()
                # 새로 들어온 마지막 결과만 Canvas에 표시
                last_index = self.Layer_Name.index(last_added_name)
                self.Show_Canvas_Layer(last_index, last_added_name)

            # G2D 콘솔 종료 후 마지막 파일까지 한 번 검사한 다음 UI 복구
            if is_final_scan:
                self.finish_live_simulation()

        except Exception as e:
            MsError(e)

    def finish_live_simulation(self):
        self.current_timer.stop()

        self.btn_Close.setText("Close")
        self.btn_Close.setEnabled(True)
        self.btn_slidePause.setEnabled(True)
        self.btn_slideStop.setEnabled(True)
        self.sld_slideBar.setEnabled(True)
        self.chk_makeImage.setEnabled(True)

        self.sld_slideBar.setMaximum(max(0, len(self.Layer_Name) - 1))

    def Set_Tree_Widget(self):        
        result = {}
        result = Get_Folder_Files(self.project_file)
        self.Dic_Tree_List=result
        self.Layer_Name=[]
        for i, c in enumerate(list(result)):
            self.Layer_List_Tree.insertTopLevelItem(i, QTreeWidgetItem([c]))
            #QML 파일 생성 확인 
            self.Copy_file(str(self.Dic_Tree_List[c]),"QML")
            #2019-09-23 박: prj 파일을 프로세스가 실행 할때 자동 관리(최박사님 모듈)
            #self.Copy_file(str(self.Dic_Tree_List[c]),"PRJ")
            self.Layer_Name.append(c)
        self.sync_result_list()

    #treewidget 클릭이벤트 클릭할때 마다 Canvas 표출 레이어 변경됨 
    def itemClicked(self, item):
        try:
            selectItem = item.text(0)
            selectIndex  = self.Layer_List_Tree.currentIndex().row()
            self.Show_Canvas_Layer(selectIndex, selectItem)
        except Exception as e:
            MsError(e)


    def apply_sidecar_qml(self, layer, raster_path):
        """
        래스터 파일과 같은 이름의 .qml 파일이 있으면 스타일을 적용한다.
        예: DEPTH_001.out -> DEPTH_001.qml
        """
        if layer is None or not layer.isValid():
            return False
        qml_path = os.path.splitext(raster_path)[0] + ".qml"
        if not ChFile_Exists(qml_path):
            return False
        layer.loadNamedStyle(qml_path)
        layer.triggerRepaint()
        return True

     #캔버스에 레이어 보여주기
    def Show_Canvas_Layer(self, index, subject, refresh=True):
        try:
            if subject not in self.Dic_Tree_List:
                raise KeyError("Result layer is not registered: {}".format(subject))
            raster_path = self.Dic_Tree_List[subject]
            self.lbl_layername.setText(subject)
            self.Clear_Canvas()
            # 결과 OUT 레이어 생성
            self.layer = QgsRasterLayer(
                raster_path,
                subject,
                "gdal"
            )
            # OUT 파일이 정상 레이어로 열리지 않으면 PNG 저장을 진행하지 않음
            if not self.layer.isValid():
                raise RuntimeError(
                    "Could not load result raster: {}".format(raster_path)
                )
            # 같은 파일명의 sidecar QML 적용
            self.apply_sidecar_qml(
                self.layer,
                raster_path
            )

            self.Canvas_Main.setDestinationCrs(self.layer.crs())
            base_map_index = self.cmb_base_map.currentIndex()

            # 결과만 표시
            if base_map_index == 0:
                QgsProject.instance().addMapLayer(self.layer, False)
                self.Canvas_Main.setLayers([self.layer])

            # Google 배경지도 + 결과
            elif base_map_index == 1:
                service_uri = (
                    "type=xyz&url=https://mt1.google.com/vt/"
                    "lyrs%3Dy%26x%3D%7Bx%7D%26y%3D%7By%7D%26z%3D%7Bz%7D"
                    "&zmax=18&zmin=0"
                )
                background_layer = QgsRasterLayer(
                    service_uri,
                    "google hybrid",
                    "wms"
                )

                if not background_layer.isValid():
                    raise RuntimeError("Could not load Google background layer.")
                QgsProject.instance().addMapLayer(
                    background_layer,
                    False
                )
                self.Canvas_Main.setLayers([
                    self.layer,
                    background_layer
                ])

            # DEM 배경 + 결과
            elif base_map_index == 2:
                dem_name = GetFile_Name(self.dem_path)
                self.base_map = QgsRasterLayer(
                    self.dem_path,
                    dem_name,
                    "gdal"
                )
                if not self.base_map.isValid():
                    raise RuntimeError(
                        "Could not load DEM layer: {}".format(
                            self.dem_path
                        )
                    )
                self.Canvas_Main.setLayers([
                    self.layer,
                    self.base_map
                ])

            self.Canvas_Main.setExtent(self.layer.extent())

            # slider 애니메이션은 renderComplete 연결 뒤 별도로 refresh해야 함
            if refresh:
                self.Canvas_Main.refresh()

            return True

        except Exception as e:
            MsError(e)
            return False


    def Get_Layer_Files(self):
        files = QFileDialog.getOpenFileNames(
            self,
            "Open simulation result files",
            "",
            "OUT (*.out)",
            options=QFileDialog.DontUseNativeDialog
        )[0]
        for path in files:
            file_name = GetFile_Name(os.path.basename(path))
            # 이미 등록된 파일은 중복 추가하지 않음
            if file_name in self.Dic_Tree_List:
                continue
            self.Dic_Tree_List[file_name] = path
            self.Layer_List_Tree.addTopLevelItem(
                QTreeWidgetItem([file_name])
            )
            self.Copy_file(path, "QML")

        self.sync_result_list()


    def Select_tree_del(self):
        try:
            root = self.Layer_List_Tree.invisibleRootItem()
            for item in self.Layer_List_Tree.selectedItems():
                name = item.text(0)
                self.Dic_Tree_List.pop(name, None)
                path = item.parent() or root
                path.removeChild(item)

            self.sync_result_list()
            if not self.Layer_Name:
                self.Clear_Canvas()
                self.lbl_layername.setText("")

        except Exception as e:
            MsError(e)

    def Clear_tree_all(self):
        try:
            self.Layer_List_Tree.clear()
            self.Dic_Tree_List.clear()
            self.Layer_Name.clear()
            self.Temp_Layer_Name.clear()

            self.sync_result_list()

            self.Clear_Canvas()
            self.lbl_layername.setText("")

        except Exception as e:
            MsError(e)
 
    def Select_Folder(self,txt):
        try:
            file_dialog = QFileDialog(self)
            current_directory=""
            folderpath=file_dialog.getExistingDirectory(self, 
                'Select directory',
                current_directory,
                QFileDialog.ShowDirsOnly)
            if CheckFolder(folderpath):
                txt.setText(folderpath) #여기서 텍스트가 바뀌면,  self.txtPng_Folder_Path.textChanged.connect(self.AddPngsInAfolderToList) 이게 호출된다.
        except Exception as e:
            MsError(e)

    def AddPngsInAfolderToList(self,txt):
            if CheckFolder(txt):
                self.SetFileList(txt)
    
    def Save_file(self,txt):
        try:
            filePath=QFileDialog.getSaveFileName(self, 'Save file name', "", "ASCII Grid (*.asc)")[0]
            if CheckFolder(GetFileDirectory_Path(filePath)):
                txt.setText(filePath)
                
        except Exception as e:
            MsError(e)

    #2019-12-11: park
    # error file list 
    def SetFileList(self,path):
        try:
            self.tblPng_List.setRowCount(0)
            self.tblPng_List.setColumnCount(1)
            self.tblPng_List.setHorizontalHeaderLabels(['Image List'])
            file_list = os.listdir(path)
            filelist = [file for file in file_list if file.endswith(".png")]

            filelist.sort(key=lambda f: int("".join(list(filter(str.isdigit, f)))))
            for fname in filelist:
                pass
            i =0
            for fichier in filelist:
                if fichier.endswith(".png"):
                    self.tblPng_List.insertRow(i)
                    self.tblPng_List.setItem(i, 0, QTableWidgetItem(fichier))
                    i = i + 1
        except Exception as e:
            MsError(e) 

    def MoveUpPng(self):
        row = self.tblPng_List.currentRow()
        column = self.tblPng_List.currentColumn()
        if row > 0:
            self.tblPng_List.insertRow(row - 1)
            for i in range(self.tblPng_List.columnCount()):
                self.tblPng_List.setItem(row - 1, i, self.tblPng_List.takeItem(row + 1, i))
                self.tblPng_List.setCurrentCell(row - 1, column)
            self.tblPng_List.removeRow(row + 1)


    def MoveDownPng(self):
        row = self.tblPng_List.currentRow()
        column = self.tblPng_List.currentColumn()
        if row>=0:
            if row < self.tblPng_List.rowCount() - 1:
                self.tblPng_List.insertRow(row + 2)
                for i in range(self.tblPng_List.columnCount()):
                    self.tblPng_List.setItem(row + 2, i, self.tblPng_List.takeItem(row, i))
                    self.tblPng_List.setCurrentCell(row + 2, column)
                self.tblPng_List.removeRow(row)


    def RemovePng(self):
        row = self.tblPng_List.currentIndex().row()
        mess="Are you sure you want to delete the selected items?"
        result=QMessageBox.question(None, "G2D",mess,QMessageBox.Yes, QMessageBox.No)
        if result == QMessageBox.Yes:
            self.tblPng_List.removeRow(row)

    def make_gif(self):
        try:
            img_list = []
            if self.tblPng_List.rowCount()>0:
                for i in range(self.tblPng_List.rowCount()):
                    frame = Image.open(self.txtPng_Folder_Path.text()+"/" + self.tblPng_List.item(i,0).text())
                    img_list.append(frame)

                duration_time=self.Interval_box.value()*1000
                img_list[0].save(self.txtGif_Path.text(), format='GIF', append_images=img_list[1:], save_all=True, duration=duration_time, loop=0)
                MsInfo("Making GIF file was completed. ")
            else:
                MsError("No PNG file was selected.")

        except Exception as ex:
            MsError(ex) 


    def Select_make_path(self,txt):
        filename = QFileDialog.getSaveFileName(self, "select output file ", "", "*.gif")[0]
        if len(filename)>0:
            txt.setText(filename)

    def Select_QML_path(self,txt):
        filename = QFileDialog.getOpenFileNames(self, "Open QML Files",'',"QML (*.QML)",options=QFileDialog.DontUseNativeDialog)[0]
        if len(filename)>0:
            txt.setText(filename[0])

    def ZoomtoExtent(self):
        try: 
            self.Canvas_Main.zoomToFullExtent()
            self.Canvas_Main.refresh()
        except Exception as e:
            MsError(e)

    def canvas_pan(self):
        try:
            actionPan = QAction(self)
            self.toolPan = QgsMapToolPan(self.Canvas_Main)
            self.toolPan.setAction(actionPan)
            self.Canvas_Main.setMapTool(self.toolPan)
        except Exception as e:
            MsError(e)

    def Copy_file(self, path, copy_type):
        try:
            if copy_type in ("QML", "Apply"):
                source_qml = self.default_qml_file
            elif copy_type == "DEM":
                source_qml = self.dem_qml_file
            else:
                raise ValueError("Unknown copy type: {}".format(copy_type))

            if not ChFile_Exists(source_qml):
                raise FileNotFoundError(
                    "QML file does not exist: {}".format(source_qml)
                )

            qml_path = os.path.splitext(path)[0] + ".qml"

            if (copy_type == "QML" and
                    path in self.Temp_Layer_Name and
                    ChFile_Exists(qml_path)):
                return

            shutil.copy2(source_qml, qml_path)
            if copy_type == "QML" and path not in self.Temp_Layer_Name:
                self.Temp_Layer_Name.append(path)

        except Exception as e:
            MsError(e)

    def enableSlide(self):
        enableList=[self.btn_pngPath, self.btn_convertPng, self.txt_pngPath,self.btn_slidePause, self.btn_slideStop, self.sld_slideBar]
        for el in enableList:
            el.setEnabled(not el.isEnabled())
    
    def changePngBtnText(self, flag):
        txt = " Stop " if flag else "Convert to PNG"
        self.btn_convertPng.setText(txt) 
        if self.btn_convertPng.text() !='Convert to PNG':
            self.chk_makeImage.setEnabled(False) # 2026.07.30. 최
        else:
            self.chk_makeImage.setEnabled(True) # 2026.07.30. 최
        
    def pngConvertImage(self):
        make_folder = self.txt_pngPath.text()
        if not CheckFolder(make_folder):
            MsInfo("Please check the folder path.")
            return

        if self.btn_convertPng.text() == "Convert to PNG":
            if not self.Layer_Name:
                MsInfo("Please select simulation result files first.")
                return

            self.changePngBtnText(True)
            self.playback_active = True
            self.slide_count = 0
            self.pause_count = 0
            self.slideImage()
        else:
            self.slideStopEvent()
            self.changePngBtnText(False)


    #슬라이드 작동
    def slideImage(self):
        try:
            if not self.playback_active:
                return

            item = self.Layer_List_Tree.topLevelItem(self.slide_count)

            if item is None:
                self.changePngBtnText(False)
                raise Warning("Please run the simulation first.")

            # 이전 렌더링이 남아 있으면 정리
            self.Canvas_Main.stopRendering()
            self.Canvas_Main.waitWhileRendering()

            self.render_frame_index = self.slide_count
            self.render_frame_name = item.text(0)

            try:
                self.Canvas_Main.mapCanvasRefreshed.disconnect(
                    self.exportMap
                )
            except (TypeError, RuntimeError):
                pass

            # Canvas 위젯이 실제 갱신된 뒤 PNG 저장
            self.Canvas_Main.mapCanvasRefreshed.connect(
                self.exportMap
            )

            # Show_Canvas_Layer() 내부에서 refresh하지 않게 함
            if not self.Show_Canvas_Layer(
                    self.render_frame_index,
                    self.render_frame_name,
                    refresh=False):
                self.playback_active = False
                return

            # 여기서 단 한 번만 렌더링 요청
            self.Canvas_Main.refresh()

        except Exception as e:
            self.playback_active = False
            self.playback_timer.stop()
            MsError(e)


    #슬라이드의 실질적인 작동 내용
    def exportMap(self):
        try:
            try:
                self.Canvas_Main.mapCanvasRefreshed.disconnect(
                    self.exportMap
                )
            except (TypeError, RuntimeError):
                pass

            if not self.playback_active:
                return

            if self.render_frame_index != self.slide_count:
                return

            check_flag = self.chk_makeImage.isChecked()
            save_path = self.txt_pngPath.text()

            if check_flag:
                png_path = os.path.join(
                    save_path,
                    self.render_frame_name + ".png"
                )

                self.Canvas_Main.saveAsImage(png_path)

            if self.slide_count < len(self.Layer_Name) - 1:
                self.slide_count += 1
                self.pause_count = self.slide_count

                self.slide_flag = True
                self.sld_slideBar.setSliderPosition(self.slide_count)
                self.slide_flag = False

                self.playback_timer.start(500)

            else:
                self.playback_active = False
                self.playback_timer.stop()

                if check_flag:
                    self.pause_count = 0
                    self.SetFileList(save_path)
                    self.txtPng_Folder_Path.setText(save_path)
                    self.changePngBtnText(False)
                    MsInfo("Converting png image file was complete.")

                self.btn_slidePause.setText(u'\u25B6')
                self.slideStopEvent()

        except Exception as e:
            self.playback_active = False
            self.playback_timer.stop()
            MsError(e)
 
    def slideStopEvent(self):
        self.playback_active = False
        self.playback_timer.stop()
        try:
            self.Canvas_Main.mapCanvasRefreshed.disconnect(
                self.exportMap
            )
        except (TypeError, RuntimeError):
            pass

        self.slide_control = False
        self.slide_flag = False
        self.btn_slidePause.setText(u'\u25B6')
        self.pause_count = 0
        self.slide_count = 0
        self.sld_slideBar.blockSignals(True)
        self.sld_slideBar.setSliderPosition(0)
        self.sld_slideBar.blockSignals(False)

        item = self.Layer_List_Tree.topLevelItem(0)
        if item:
            self.lbl_layername.setText(item.text(0))


    def slidePauseEvent(self):
        try:
            if self.btn_slidePause.text() == u'\u25B6':
                if not self.Layer_Name:
                    return
                self.playback_active = True
                self.slide_flag = True
                self.btn_slidePause.setText(chr(124) + chr(124))
                self.slide_count = self.pause_count
                self.slideImage()

            else:
                # Pause: 다음 프레임 예약을 취소하고 현재 위치 유지
                self.playback_active = False
                self.playback_timer.stop()
                self.slide_control = False
                self.slide_flag = False
                try:
                    self.Canvas_Main.mapCanvasRefreshed.disconnect(
                        self.exportMap
                    )
                except (TypeError, RuntimeError):
                    pass
                self.pause_count = self.slide_count
                self.btn_slidePause.setText(u'\u25B6')

        except Exception as e:
            self.playback_active = False
            self.playback_timer.stop()
            MsError(e)

    def Clear_Canvas(self):
        try:
            #레이어가 자꾸 잡혀 있어서 프로세스가 사용중으로 나옴 그래서 레이어 삭제 기능 추가해서 넣음
            self.layer =None
            layers = self.Canvas_Main.layers()
            for l in layers:
                QgsProject.instance().removeMapLayer(l.id())
#             QgsProject.instance().removeAllMapLayers()
            self.Canvas_Main.clearCache()
        except Exception as e:
            pass

    def baseMap_Changed(self):
        try:
            if self.cmb_base_map.currentIndex()==1:
                if self.layer is None:
                    service_uri = "type=xyz&url=https://mt1.google.com/vt/lyrs%3Dy%26x%3D%7Bx%7D%26y%3D%7By%7D%26z%3D%7Bz%7D&zmax=18&zmin=0"
                    tms_layer = QgsRasterLayer(service_uri, "google hybrid", "wms")
                    QgsProject.instance().addMapLayer(tms_layer, False)
                    self.Canvas_Main.setLayers([tms_layer])
                    self.Canvas_Main.setExtent(tms_layer.extent())
                    self.Canvas_Main.refresh()
                else:
                    service_uri = "type=xyz&url=https://mt1.google.com/vt/lyrs%3Dy%26x%3D%7Bx%7D%26y%3D%7By%7D%26z%3D%7Bz%7D&zmax=18&zmin=0"
                    tms_layer = QgsRasterLayer(service_uri, "google hybrid", "wms")
                    QgsProject.instance().addMapLayer(tms_layer, False)
                    self.Canvas_Main.setLayers([self.layer]+[tms_layer])
                    self.Canvas_Main.setExtent(self.layer.extent())
            elif self.cmb_base_map.currentIndex()==2:
                self.base_map=None
                if self.layer is None:
                    name = GetFile_Name(self.dem_path)
                    self.base_map = QgsRasterLayer(self.dem_path, name, "gdal")
                    self.Canvas_Main.setLayers([self.base_map])
                    self.Canvas_Main.setExtent(self.base_map.extent())
                    self.Canvas_Main.refresh()
                else:
                    name = GetFile_Name(self.dem_path)
                    self.base_map = QgsRasterLayer(self.dem_path, name, "gdal")
                    self.Canvas_Main.setLayers([self.layer]+[self.base_map])
                    self.Canvas_Main.setExtent(self.layer.extent())
                    self.Canvas_Main.refresh()
            else:
                self.base_map=None
        except Exception as e:
            MsError(e) 
            
    def runMaxValue(self):
        try:
            rstPath = self.txt_maxValuePath.text()
            filename, file_extension = os.path.splitext(rstPath)
            if file_extension == "":
                rstPath=rstPath+".asc"
            exePath = os.path.join(os.path.dirname(__file__), "G2D/Max_Value_ASC_Create.exe")
            items = self.Layer_List_Tree.selectedItems()
            limit = self.spb_maxValue.value()
            
            if not CheckFolder(GetFileDirectory_Path(rstPath)):
                raise Warning("Please check the save file path")
            if len(items)==0:
                raise Warning("Please select the layers")
            
            with tempfile.TemporaryDirectory() as tmpdir:
                for item in items:
                    fileName = item.text(0)
                    filePath = self.Dic_Tree_List[fileName]
                    shutil.copy2(filePath, os.path.join(tmpdir, fileName+".out"))
                    
                arg = f'"{exePath}" "{tmpdir}" {limit} "{rstPath}"'
                Execute(arg) #util.py 함수

                # 2022.02.22. 최 ========================
                filename, file_extension = os.path.splitext(rstPath)
                qml_path_name = rstPath.replace(file_extension, ".qml")
                shutil.copy2(self.default_qml_file, qml_path_name)
                prj_path_name = qml_path_name.replace(".qml", ".prj")
                source_prj_name = items[0].text(0) + ".prj"
                project_folder = os.path.dirname(os.path.abspath(self.project_file))
                source_prj_path = os.path.join(project_folder, source_prj_name)

                shutil.copy2(source_prj_path, prj_path_name)
                # 2022.02.22. 최 ========================                
                
            MsInfo("The max. value calculation was completed. ")
        except Exception as e:
            MsError(e)

    def is_simulation_running(self):
        return bool(self.status and self.status.get("running", False))


    def sync_result_list(self):
        """
        Tree 순서를 기준으로 Layer_Name과 slider 상태를 동기화한다.
        """
        self.Layer_Name = []

        for row in range(self.Layer_List_Tree.topLevelItemCount()):
            item = self.Layer_List_Tree.topLevelItem(row)
            name = item.text(0)

            if name in self.Dic_Tree_List:
                self.Layer_Name.append(name)

        max_index = max(0, len(self.Layer_Name) - 1)

        self.sld_slideBar.blockSignals(True)
        self.sld_slideBar.setMaximum(max_index)

        if self.Layer_Name:
            current_index = min(self.sld_slideBar.value(), max_index)
            self.sld_slideBar.setValue(current_index)
            self.slide_count = current_index
            self.pause_count = current_index
        else:
            self.sld_slideBar.setValue(0)
            self.slide_count = 0
            self.pause_count = 0

        self.sld_slideBar.blockSignals(False)

    def is_ready_raster(self, path, final_scan=False):
        try:
            file_size = os.path.getsize(path)
            if file_size <= 0:
                return False

            previous_size = self._out_file_sizes.get(path)
            self._out_file_sizes[path] = file_size
            # 실행 중에는 두 번 연속 파일 크기가 같을 때만 사용
            if not final_scan and previous_size != file_size:
                return False
            layer_name = os.path.splitext(os.path.basename(path))[0]
            test_layer = QgsRasterLayer(path, layer_name, "gdal")

            return test_layer.isValid()

        except OSError:
            return False